from flask import Flask, render_template
import json
from pathlib import Path
import random

app = Flask(__name__)

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "results.json"

def load_results():
    with open(DATA_FILE, "r") as f:
        return json.load(f)

@app.route("/")
def home():
    results = load_results()
    latest = results[-1]

    predictions = []
    for _ in range(5):
        predictions.append(f"SK {random.randint(100000,999999)}")

    return render_template(
        "index.html",
        latest=latest,
        predictions=predictions
    )

if __name__ == "__main__":
    app.run(debug=True)